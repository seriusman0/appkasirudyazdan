<?php
delete("tb_barang", $_GET['id']);
